import java.sql.*;
import java.text.DecimalFormat;
import java.util.*;
import java.awt.*;
import java.io.IOException;
import javax.*;

import chemaxon.formats.MolFormatException;
import chemaxon.formats.MolImporter;
import chemaxon.license.LicenseProcessingException;
import chemaxon.marvin.alignment.AlignmentException;
import chemaxon.marvin.alignment.AtropIsomerDetector;
import chemaxon.marvin.calculations.*;
import chemaxon.marvin.plugin.*;
import chemaxon.struc.Molecule;

public class LipinskiFilter { // implements Comparable<Integer> {
	
	// Declaring the instance variables
	 private logPPlugin Lplug;
	 private HBDAPlugin HAplug;
	 private TPSAPlugin PSAplug;
	 private TopologyAnalyserPlugin rbplug;
	
	 
	 private ConnectDB cdb;
	 private int total_rows;
	 private double logpWeight;
	 private double mwWeight;
	 private double hbaWeight;
	 private double hbdWeight;
	 private double psaWeight;
	 private double rotbWeight;
	 private DecimalFormat df;
	 
	 
	 
	 /** Default Constructor */
	 public LipinskiFilter() {
		 Lplug = new logPPlugin();
		 HAplug = new HBDAPlugin();
		 PSAplug = new TPSAPlugin();
		 rbplug = new TopologyAnalyserPlugin();
		 
		 
		cdb = new ConnectDB();
		cdb.connect();
		 total_rows = 30;
		 
		 logpWeight = 0.25;
		 mwWeight = 0.50;
		 hbaWeight = 0.00;
		 hbdWeight = 0.50;
		 psaWeight = 0.00;
		 rotbWeight = 0.50;
		 df = new DecimalFormat("#.###");
	 }
	 
	 
	 
	 /** Method for calculating logP and adding these values to the table 
	 * @throws PluginException */
	 // Note: The code used was adapted from  here : https://apidocs.chemaxon.com
	 public void calculateLogP() throws PluginException {
		
		
		 
	   // set parameters
	     Lplug.setCloridIonConcentration(0.2);
	     Lplug.setNaKIonConcentration(0.2);

	   
	     // set result types
	     Lplug.setUserTypes("logPTrue,logPMicro");
	        
	   
	    // LogP is calculated for each input molecule and added to the molecule table
	    
	     try { 
	     chemaxon.license.LicenseManager.setLicenseFile("license.cxl");   //  setting the license file for API usage
	        
	     
	     MolImporter mi = new MolImporter("Maybridge_H5a.sdf");
	     Molecule target = null;
	     int i = 1;
	        
	     while ((target = mi.read()) != null && i <= total_rows) {

	            
	            Lplug.setMolecule(target);				// set the input molecule
	            Lplug.run();						// run the calculation
	            double logp = Lplug.getlogPTrue(); 		// get the overall logP value
	            String flogp = df.format(logp);			// Format result to 2dp
	            double nlogp = Double.parseDouble(flogp);  // Convert back to type double
	          
	            
	            cdb.addLogp(nlogp, i);				// Add the value to the corresponding molecule
	            i++;

	         
	        }  
	        mi.close();
	    	}
	    	catch ( MolFormatException e) {
	    	//	System.out.println("There's a molFormatException exception");
	    		e.printStackTrace();
	    		
	    	} catch (IOException e) {
	    	//	System.out.println("There's an IO exception");
				e.printStackTrace();
				
			} catch (PluginException e) {
			//	System.out.println("There's a Plugin exception");
				e.printStackTrace();
				
			} catch (LicenseProcessingException e) {
			//	System.out.println("There's a problem with the licence");
				e.printStackTrace();
			}
	     System.out.println("LogP details have been added successfully");
	    
		}
	 
	 
	 
	 
	 /** Method for calculating the number of Hydrogen bond acceptors and donors
	 * @throws PluginException */
	 public void calculateHBDA() throws PluginException {
		 
		 
		 
		// set parameters
		 HAplug.setDoublePrecision(2);
		 HAplug.setpHLower(2.0);
		 HAplug.setpHUpper(12.0);
		 HAplug.setpHStep(2.0);
		 
		try {
			
			chemaxon.license.LicenseManager.setLicenseFile("license.cxl");   //  setting the license file for API usage
			
		 // read input molecule
		 MolImporter mi = new MolImporter("Maybridge_H5a.sdf");
		 Molecule mol;
		 int i = 1;
		
				 
		 while ((mol = mi.read()) != null && i <= total_rows) {
			
			// set target molecule
			 HAplug.setMolecule(mol);
			 
			 // run the calculation
			 HAplug.run();
			 
			 int molAcceptorCount = HAplug.getAcceptorAtomCount();
			 int molDonorCount = HAplug.getDonorAtomCount();
			 
			 cdb.addHBA(molAcceptorCount, i);
			 cdb.addHBD(molDonorCount, i);
			 
			 i++;
			
		 }
		 mi.close();
		 }
		catch (MolFormatException e) {
		e.printStackTrace();
		
		} catch (IOException e) {
			e.printStackTrace();
			
		} catch (LicenseProcessingException e) {
			e.printStackTrace();
			
		}

		System.out.println("Acceptors and donors have been added successfully");
		
	 }
	 
	 
	 
	 /**  Method for calculating the topological surface area, and adding these values to the database */
	 public void calculateTPSA() {
		
		
		 try {
				
				chemaxon.license.LicenseManager.setLicenseFile("license.cxl");   //  setting the license file for API usage
		 
		 // read input molecule
		    MolImporter mi = new MolImporter("Maybridge_H5a.sdf");
		    Molecule mol;
		    int i = 1;
		    
		    while ((mol = mi.read()) != null && i <= total_rows) {
		    	 
				    PSAplug.setpH(7.4);						// set the pH parameter

				    
				    PSAplug.setMolecule(mol);					// set target molecule
				        
				    PSAplug.run();   							// run the calculation

				    double SA = PSAplug.getSurfaceArea();   // get result
				    String fSA = df.format(SA);				// Round to 2dp
				    double nSA = Double.parseDouble(fSA);	// Convert back to type double
				    
				    
				    cdb.addPSA(nSA, i);
				    

				    i++;
		    }
		    mi.close();
		}
		catch (IOException e) {
			e.printStackTrace();
			
		} catch (PluginException e) {
			e.printStackTrace();
			
		} catch (LicenseProcessingException e) {
			
			e.printStackTrace();
			
		}

		    
		System.out.println("TPSA details have been added successfully");  

	}
	 
	 
	 
	 /**  Method for calculating the number of rotatable bonds, and adding these values to the database 
	 * @throws AlignmentException */
	 public void calculateROTB() throws AlignmentException {
		 
		 
		 
		 try {
				
				chemaxon.license.LicenseManager.setLicenseFile("license.cxl");   //  setting the license file for API usage
		 
		 // read input molecule
		    MolImporter mi = new MolImporter("Maybridge_H5a.sdf");
		    Molecule mol;
		    int i = 1;
		   
		    
		    while ((mol = mi.read()) != null && i <= total_rows) {
		    	
		    	rbplug.setMolecule(mol);		// set target molecule
		    	

		        // run the calculation
		        rbplug.run();

		        // get  result
		        int rotb = rbplug.getRotatableBondCount();;				
				   
				   cdb.addROTB(rotb, i);
				    
				    i++;
				    		    
		    }
		    mi.close();
		}
		catch (IOException e) {
			e.printStackTrace();
			
		} catch (LicenseProcessingException e) {
			e.printStackTrace();
			
		} catch (PluginException e) {
			e.printStackTrace();
			
		}

		    
		System.out.println("ROTB details have been added successfully"); 
	 }
	 
	 
	 
	 
	 
	 /**  Method for calculating the drug-likeness score, and adding these values to the database */
	 public void calculateDrugLikeness() {
		 
		 double [] logP = cdb.getLogp();
		 double [] molweight = cdb.getMolweight();
		 int [] hba = cdb.getHBA();
		 int[] hbd = cdb.getHBD();
		 double [] psa = cdb.getPSA();
		 int [] rotb = cdb.getRotb();
		 
		 int j = 1;
		 
		 for (int i = 0; i < total_rows; i++) {
			 
			 double Wlogp = logP[i] * logpWeight;
			 double Wmolweight = molweight[i] * mwWeight;
			 double Whba = hba[i] * hbaWeight;
			 double Whbd = hbd[i] * hbdWeight;
			 double Wpsa = psa[i] * psaWeight;
			 double Wrotb = rotb[i] * rotbWeight;
			 
			 double drugLikeness = Wlogp + Wmolweight + Whba + Whbd + Wpsa + Wrotb;
			 String fdrugLikeness = df.format(drugLikeness);
			 double ndrugLikeness = Double.parseDouble(fdrugLikeness);
			 
			 cdb.addScore(ndrugLikeness, j);
			 
			 j++;
		 }
		 
		 System.out.println("Drug-likeness scores have been added successfully"); 
	 }


	 
	 
	
	 
	 
}


