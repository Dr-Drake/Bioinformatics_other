import chemaxon.marvin.MolPrinter;
import chemaxon.marvin.beans.MSketchPane;
import chemaxon.marvin.beans.MarvinPane;
import chemaxon.struc.Molecule;
 import chemaxon.formats.MolImporter;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.image.BufferedImage;
 import java.io.File;
 import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
import javax.swing.table.DefaultTableModel;

import java.awt.event.MouseListener;


 public class ChemGUI extends JFrame implements ActionListener, MouseListener {
	 
	// Declaring the instance variables
		
		private JLabel Log, Mw, Ha, Hd, Ps, Rt, dash1, dash2, dash3, dash4, dash5, dash6, picLabel;
		private JLabel setRows, search;
		private JPanel MwPanel, logPanel, tablePanel, HaPanel, HdPanel, PsPanel, RtPanel, AppPanel, picPanel;
		private JPanel iNPanel, tNPanel, dlPanel, propPanel;
		private JPanel northPanel, southPanel, resPanel, rowPanel, threshPanel, viewPanel;
		private JButton apply, searchButton, reset;
		private JTable table;
		private JTextField logpStart, logpEnd, MwStart, MwEnd, haStart, haEnd, hdStart, hdEnd, psaStart, psaEnd, rtStart, rtEnd;
		private JTextField sText;
		private JMenuBar mbar;
		private JMenu menu, Dgscore, options;
		private JMenuItem lpski, ldlikness, specify, rank, rank1, reSearch, dpSmiles;
		private JTextArea infoArea, testA;
		private ConnectDB con;
		private DefaultTableModel dtable;
		private Border bd = BorderFactory.createEtchedBorder(EtchedBorder.LOWERED);
		private ImageIcon ic;
		
		private String count, limit, thold, thold1, view, view1;
		private boolean fSmiles;
		
	 
	// Default constructor
	 public ChemGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Chemical Database Portal");
		setSize(1000,800);
		
		
		con = new ConnectDB();
		
		ic = new ImageIcon("White space2.jpg", "JPEG");
		
		limit = "Rows in set: ";
		thold = "Recomended threshold ";
		thold1 = "for drug-likeness score is ≤ 258.75";
		view = "Click on the formula for";
		view1 = "2d visualization of the molecule";
		fSmiles = false;
		
		layOutTable();
		layoutFilters(); 
		layOutComponents();
		layoutProperties();
		
		 
			
			
		//TableModel mod =	table.getModel();
		
	 }
	 
	 
	 
	 private void layOutComponents() {
		 
		
		
		
		// Sorting out the Menu bar
		 
		search = new JLabel("Search via formula: ");
		sText = new JTextField(10);
		searchButton = new JButton("Search");
		searchButton.addActionListener(this);
		
		 
		mbar = new JMenuBar();
		setJMenuBar(mbar);
		menu = new JMenu("Filter");
		Dgscore = new JMenu("Rank by Drug-Likeness");
		options = new JMenu("Options");
		mbar.add(menu);
		mbar.add(options);
		mbar.add(search);
		mbar.add(sText);
		mbar.add(searchButton);
		
		
		
		
		lpski = new JMenuItem("Lipinski compliance");
		lpski.addActionListener(this);
		ldlikness = new JMenuItem("Lead-like compliance");
		ldlikness.addActionListener(this);
		specify = new JMenuItem("Detailed Filter");
		specify.addActionListener(this);
		rank = new JMenuItem("Ascending");
		rank.addActionListener(this);
		rank1 = new JMenuItem("Descending");
		rank1.addActionListener(this);
		reSearch = new JMenuItem("Search");
		reSearch.addActionListener(this);
		reSearch.setEnabled(false);
		dpSmiles = new JMenuItem("Fetch Smiles");
		dpSmiles.addActionListener(this);
		
		
		Dgscore.add(rank);
		Dgscore.add(rank1);
		
		menu.add(lpski);
		menu.add(ldlikness);
		menu.add(specify);
		options.add(Dgscore);
		options.add(dpSmiles);
		options.add(reSearch);
		
		
		
		
		
		
	// Disabling the Filters
			disableFilters();
			    
			
	 }
	 
	/**
	 *  The Layout the design for the table 
	 */
	 private void layOutTable() {
		  
		 
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
		String [] [] data = con.getData();
		 
		//Layout for the Table 
			
			dtable = new DefaultTableModel(data, header);
			table = new JTable(dtable);
			table.setAutoCreateRowSorter(true);
			table.setBorder(bd);
			table.addMouseListener(this);
			
			int rowCount = dtable.getRowCount();
			count = "" + rowCount;
			
			// Adding the table to a scroll panel
			JScrollPane scroll = new JScrollPane(table);          
			scroll.setPreferredSize(new Dimension(150, 300));
			scroll.setMaximumSize(getPreferredSize());
			this.add(scroll, BorderLayout.CENTER);
	  }
	 
	 
	 
	 private void layoutFilters() {
		 
		 //Creating the Main bottom panel
		 tablePanel = new JPanel(new GridLayout(6,3));
			
			
		 // Creating the panels added to the main bottom panel
			logPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			MwPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			HaPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			HdPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			PsPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			RtPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
			AppPanel = new JPanel (new FlowLayout(FlowLayout.CENTER));
			
			
		// Panel design for LogP filter
			Log = new JLabel("LogP: ");				
			dash1 = new JLabel("--");
			logpStart = new JTextField(10);
			logpStart.setText("0.00");
			logpEnd = new JTextField(10);
			logpEnd.setText("5.00");
			
			logPanel.add(Log);
			logPanel.add(logpStart);
			logPanel.add(dash1);
			logPanel.add(logpEnd);


			
		// Panel design for Molecular Weight Filter
			Mw = new JLabel("Molecular Weight: ");			
			dash2 = new JLabel("--");
			MwStart = new JTextField(10);
			MwStart.setText("0.00");
			MwEnd = new JTextField(10);
			MwEnd.setText("500");
			
			MwPanel.add(Mw);
			MwPanel.add(MwStart);
			MwPanel.add(dash2);
			MwPanel.add(MwEnd);
		
			
			// Panel design for Hydrogen Acceptors Filter
			Ha = new JLabel("Hydrogen Acc: ");			
			dash3 = new JLabel("--");
			haStart = new JTextField(10);
			haStart.setText("0.00");
			haEnd = new JTextField(10);
			haEnd.setText("10");
			
			HaPanel.add(Ha);
			HaPanel.add(haStart);
			HaPanel.add(dash3);
			HaPanel.add(haEnd);

			
			// Panel design for Hydrogen Donors Filter
			Hd = new JLabel("Hydrogen Don: ");			
			dash4 = new JLabel("--");
			hdStart = new JTextField(10);
			hdStart.setText("0.00");
			hdEnd = new JTextField(10);
			hdEnd.setText("5.00");
			
			HdPanel.add(Hd);
			HdPanel.add(hdStart);
			HdPanel.add(dash4);
			HdPanel.add(hdEnd);
		
			
		// Sorting out the panel for Polar Surface Area Filter
			Ps = new JLabel("PSA: ");			
			dash5 = new JLabel("--");
			psaStart = new JTextField(10);
			psaStart.setText("0.00");
			psaEnd = new JTextField(10);
			psaEnd.setText("140.00");
			
			PsPanel.add(Ps);
			PsPanel.add(psaStart);
			PsPanel.add(dash5);
			PsPanel.add(psaEnd);
		
			
			// Sorting out the panel for Rotatable bonds Filter
			Rt = new JLabel("ROTB: ");			
			dash6 = new JLabel("--");
			rtStart = new JTextField(10);
			rtStart.setText("0.00");
			rtEnd = new JTextField(10);
			rtEnd.setText("10.00");
			
			RtPanel.add(Rt);
			RtPanel.add(rtStart);
			RtPanel.add(dash6);
			RtPanel.add(rtEnd);
			
			
			// Panel design for the button that executes Filter	
			apply = new JButton("Apply");		
			apply.addActionListener(this);  
			AppPanel.add(apply);
			
			
		// Adding filter panels to the main bottom panel
			tablePanel.add(logPanel);		
			tablePanel.add(MwPanel);
			tablePanel.add(HaPanel);
			tablePanel.add(HdPanel);
			tablePanel.add(PsPanel);
			tablePanel.add(RtPanel);
			tablePanel.add(AppPanel);
		
			
			this.add(tablePanel, BorderLayout.SOUTH);
	 }
	 
	 
	/**
	 *  The layout design for the west side of the frame 
	 */
	 private void layoutProperties() {
		 	
		// Creating the main property panel 	
		propPanel = new JPanel();
		propPanel.setLayout(new BoxLayout(propPanel, BoxLayout.Y_AXIS));
		
		
		// Creating panels that hold the reset button
		resPanel = new JPanel();
		rowPanel = new JPanel(new FlowLayout(FlowLayout.LEFT)); 
		
		
		
		// Designing the panel for the button that resets the table
		reset = new JButton("Reset Table");
		reset.addActionListener(this);
		resPanel.setAlignmentX(LEFT_ALIGNMENT);
		resPanel.add(reset);
		
		
		// Designing the panel for the information area at the bottom left
		
		infoArea = new JTextArea();
		infoArea.setFont(new Font("Courier", Font.BOLD, 14));
		infoArea.setPreferredSize(new Dimension(300, 300));
		infoArea.setMaximumSize(getPreferredSize());
		infoArea.setAlignmentX(LEFT_ALIGNMENT);
		infoArea.setEditable(false);
		infoArea.append(limit);
		infoArea.append(count);
		infoArea.append("\n" + "\n");
		infoArea.append(thold + "\n");
		infoArea.append(thold1);
		infoArea.append("\n" + "\n");
		infoArea.append(view + "\n");
		infoArea.append(view1);
		
		// Designing the panel for displaying of row counts
		setRows = new JLabel();
		setRows.setAlignmentX(LEFT_ALIGNMENT);;
		setRows.setBorder(bd);
		setRows.setIcon(ic);
		setRows.setPreferredSize(new Dimension(200, 300));
		setRows.setMaximumSize(getPreferredSize()); 
		
		testA = new JTextArea();
		testA.setPreferredSize(new Dimension(300, 300));
		
		
		
		// Adding all panels to main panel
		propPanel.add(resPanel);
		propPanel.add(setRows);
		propPanel.add(infoArea);
		
			
		this.add(propPanel, BorderLayout.WEST);
					
	 }
	 
	 
	 
	/**
	 * This method updates the display on the text Area
	 */
	 public void updateInfo() {
		 
		 infoArea.setText("");
		 infoArea.append(limit);
			infoArea.append(count);
			infoArea.append("\n" + "\n");
			infoArea.append(thold + "\n");
			infoArea.append(thold1);
			infoArea.append("\n" + "\n");
			infoArea.append(view + "\n");
			infoArea.append(view1);
	 }
	 
	 
	 
	 /**
	  *  This method returns the image object for a smiles string
	  * @param x - the smiles string
	  * @return
	  * @throws IOException
	  */
	 
	  public  BufferedImage createTestImage(String x) throws IOException {
	        // Create a molecule
	        Molecule mol = MolImporter.importMol(x);
	        
	        // Create a writable image
	        BufferedImage im = new BufferedImage(300, 250, BufferedImage.TYPE_INT_ARGB);
	       
	        Graphics2D g = im.createGraphics();
	       
	        // Clear background
	        g.setColor(Color.white);
	        g.fillRect(0, 0, im.getWidth(), im.getHeight());
	       
	        // Draw the bounding rectangle
	       // g.setColor(Color.red);
	        Rectangle rect = new Rectangle(30, 30, 250, 200);
	        g.draw(rect);
	        
	        // Paint the molecule
	        MolPrinter molPrinter = new MolPrinter(mol);
	        molPrinter.setScale(molPrinter.maxScale(rect)); // fit image in the rectangle
	        molPrinter.setBackgroundColor(Color.white);
	        molPrinter.paint(g, rect);
	        
	        return im;
	     }
	 

	  
	  
	  
	  
	  public void showTable(BufferedImage x) {
	  
      
      setRows.setIcon(new ImageIcon(x));
	 

	  }
	  
	  
	  
	
	/**
	 *  This method returns the number of rows that are not empty	 
	 * @param x
	 * @return
	 */
	 
	private int checkNull(String [][] x) {
		String[] row = new String [x.length];
		int count = 0;
		
		for (int i = 0; i< row.length; i++) {
			
			row[i] = x[i][0];
			if (row[i] == null) {
				//System.out.println(row[i]);
				break;
			}
			count++;
		}
		return count;
	}
	
	
	
	public void disableFilters() {
		
		
		logpStart.setText("0.00");
		logpEnd.setText("5.00");
		MwStart.setText("0.00");
		MwEnd.setText("500");
		haStart.setText("0.00");
		haEnd.setText("10");
		hdStart.setText("0.00");
		hdEnd.setText("5.00");
		psaStart.setText("0.00");
		psaEnd.setText("140.00");
		rtStart.setText("0.00");
		rtEnd.setText("10.00");
		
		
		
		logpStart.setEditable(false);
		logpEnd.setEditable(false);
		MwStart.setEditable(false);
		MwEnd.setEditable(false);
		haStart.setEditable(false); 
		haEnd.setEditable(false); 
		hdStart.setEditable(false); 
		hdEnd.setEditable(false); 
		psaStart.setEditable(false); 
		psaEnd.setEditable(false); rtStart.setEditable(false); rtEnd.setEditable(false);
		
		apply.setEnabled(false);
	}

	  
	
	/**
	 * This method enables the use of the filter textFields
	 */
	public void enableFilters() {
		logpStart.setEditable(true);
		logpEnd.setEditable(true);
		MwStart.setEditable(true);
		MwEnd.setEditable(true);
		haStart.setEditable(true); 
		haEnd.setEditable(true); 
		hdStart.setEditable(true); 
		hdEnd.setEditable(true); 
		psaStart.setEditable(true); 
		psaEnd.setEditable(true); rtStart.setEditable(true); rtEnd.setEditable(true);
		
		apply.setEnabled(true);
	}
	
	
	
	/**
	 * This method filters out molecules that do not comply with Lipinski's rule of 5
	 */
	public void processLipinski() {
		
		String [][] lipinski = con.getLipinskiTable();
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
	
		int notNull = checkNull(lipinski);
		
		
		
		dtable.setDataVector(lipinski, header);
		dtable.setRowCount(notNull);
		
		
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		disableFilters();
		
	}
	
	
	
	/**
	 * This method filters out molecules that are not situated with the properties of lead-likeness
	 */
	public void processLeadLikeness() {
		String [][] leadLikeness = con.getLeadLikeness();
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
	
		int notNull = checkNull(leadLikeness);
		
		
		
		dtable.setDataVector(leadLikeness, header);
		dtable.setRowCount(notNull);
		
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		disableFilters();
	}
	
	
	
	
	/**
	 *  This method filters the table based on the specifications given by the user
	 */
	public void processDetailedFilter() {
		
		
		
		// The following persists if any of the text fields are empty. It also shows an error message.
		   for(;;) {
		   
		   if (logpStart.getText().isEmpty() || logpEnd.getText().isEmpty() || MwStart.getText().isEmpty() || MwEnd.getText().isEmpty() || haStart.getText().isEmpty() ||haEnd.getText().isEmpty() || hdStart.getText().isEmpty() || hdEnd.getText().isEmpty() || psaStart.getText().isEmpty() || psaEnd.getText().isEmpty() || rtStart.getText().isEmpty() || rtEnd.getText().isEmpty() ) {
			   JOptionPane.showMessageDialog(null, "Don't Leave any parameter unspecified", "Missing Information", JOptionPane.ERROR_MESSAGE);
			   return;
		   }
		   else break;
		   
		   }
		   
		   try {
		   
		  // These String variables store all the Specified parameters
		   String logS = logpStart.getText();
		   String logE = logpEnd.getText();
		   String mWS = MwStart.getText();
		   String mWE = MwEnd.getText();
		   String haS = haStart.getText();
		   String haE = haEnd.getText();
		   String hdS = hdStart.getText();
		   String hdE = hdEnd.getText();
		   String psaS = psaStart.getText();
		   String psaE = psaEnd.getText();
		   String rtS = rtStart.getText();
		   String rtE = rtEnd.getText();
			
		   // The String variables are parsed into doubles
			double lS = Double.parseDouble(logS);
			double lE = Double.parseDouble(logE);
			double mS = Double.parseDouble(mWS);
			double mE = Double.parseDouble(mWE);
			double HaS = Double.parseDouble(haS);
			double HaE = Double.parseDouble(haE);
			double HdS = Double.parseDouble(hdS);
			double HdE = Double.parseDouble(hdE);
			double pS = Double.parseDouble(psaS);
			double pE = Double.parseDouble(psaE);
			double rS = Double.parseDouble(rtS);
			double rE = Double.parseDouble(rtE);
			
		
		// The specified parameters are used in the method to retrieve the table with specified contents
			
		String [][] newTable = con.getSpecificTable(mS, mE, lS, lE, HaS, HaE, HdS, HdE, pS, pE, rS, rE);
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
		
		int notNull = checkNull(newTable);
		dtable.setDataVector(newTable, header);
		dtable.setRowCount(notNull);
		
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		   }
		   catch (Exception ex) {
			   // If numbers are not entered, error message is shown
			   JOptionPane.showMessageDialog(null, "Enter numbers in the Specified fields", "Enter Numbers Only", JOptionPane.ERROR_MESSAGE);
		   }
	}
	
	
	
	
	
	public void processQuery() {
		
		// The following persists if any of the text fields are empty. It also shows an error message.
		   for(;;) {
		   
		   if (sText.getText().isEmpty()) {
			   JOptionPane.showMessageDialog(null, "Enter search information", "Missing Information", JOptionPane.ERROR_MESSAGE);
			   return;
		   }
		   else break;
		   
		   }
		
		
		
		
		String [][] searchTable = con.getQueriedTable(sText.getText());
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
	
		int notNull = checkNull(searchTable);
		
		
		
		dtable.setDataVector(searchTable, header);
		dtable.setRowCount(notNull);
		
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		disableFilters();
	}
	
	
	
	
	public void resetTable() {
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
		String [] [] data = con.getData();
		
		dtable.setDataVector(data, header);
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		disableFilters();
	}
	
	
	public void setDefaultTable() {
		con.isAscendingOrder(false);
		con.isDescendingOrder(false);
		String [] header = {"Formula", "Molecular Weight", "LogP", "H-Acceptors", "H-Donors", "Polar SA", "Rotatable bonds", "Drug-likeness"};
		String [] [] data = con.getData();
		
		dtable.setDataVector(data, header);
		int rowCount = dtable.getRowCount();
		count = "" + rowCount;
		
		updateInfo();
		disableFilters();
	}


	
	
	public void displaySmiles(String x) {
		
		sText.setText(x);
		
		
		reSearch.setEnabled(true);
		disableFilters();
	}
	
	
	
	
		
	
	public void processScoreAscending() {
		con.isAscendingOrder(true);
		con.isDescendingOrder(false);
		resetTable();
		
	
	
	}
	
	
	public void processScoreDescending() {
		con.isAscendingOrder(false);
		con.isDescendingOrder(true);
		resetTable();
	}
	
	
	

	  
	  
	
	  
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == lpski) {
			
			processLipinski();
			
			}
		
		else if (e.getSource() == apply) {
			
			processDetailedFilter();
		}
		
		else if (e.getSource() == specify) {
			enableFilters();
		}
		
		else if (e.getSource() == ldlikness) {
			processLeadLikeness();
		}
		
		else if (e.getSource() == reset) {
			setDefaultTable();
			search.setText("Search via formula: ");
			reSearch.setEnabled(false);
			searchButton.setEnabled(true);
			sText.setEditable(true);
		}
		
		else if (e.getSource() == rank) {
			
			processScoreAscending();
		}
		
		else if (e.getSource() == rank1) {
			processScoreDescending();
		}
		
		else if (e.getSource() == searchButton) {
			processQuery();
		}
		
		else if (e.getSource() == dpSmiles) {
			search.setText("Smiles format: ");
			reSearch.setEnabled(true);
			searchButton.setEnabled(false);
			
			fSmiles = true;
		}
		
		else if (e.getSource() == reSearch) {
			search.setText("Search via formula: ");
			fSmiles = false;
			reSearch.setEnabled(false);
			searchButton.setEnabled(true);
			sText.setEditable(true);
		}

		
	}



	@Override
	public void mouseClicked(MouseEvent e) {
		
		
		int row = table.rowAtPoint(e.getPoint());		//gets row number of cell clicked
		int col = table.columnAtPoint(e.getPoint());	// gets column number of cell clicked
		
		String formula = (String) table.getValueAt(row, col);   // gets value of the cell at particular coordinates
		String ans = con.getSmiles(formula);			// Transfers value to a method that uses that information
													// as part of a query
		if (fSmiles == true) {
			
			displaySmiles(ans);
			reSearch.setEnabled(true);
		}
		
		BufferedImage im;
		try {
			im = createTestImage(ans);				// This image object store an image returned by the createTestImage() method
			showTable(im);						// This method helps display the image on the GUI
			
			
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
			
		
		
	}



	@Override
	public void mouseEntered(MouseEvent e) {
		
		}
		
	



	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}



	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	 

}
