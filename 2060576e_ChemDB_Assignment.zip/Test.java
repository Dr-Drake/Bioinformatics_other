import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Vector;

import javax.imageio.ImageIO;

import chemaxon.license.LicenseProcessingException;
import chemaxon.marvin.alignment.AlignmentException;
import chemaxon.marvin.plugin.PluginException;

public class Test {

	public static void main(String[] args) throws IOException, PluginException, LicenseProcessingException, AlignmentException {
		// TODO Auto-generated method stub
		
	
	//LipinskiFilter lf = new LipinskiFilter();
	//int [] lp; //new double[30];
	ConnectDB con = new ConnectDB();
	con.connect();
	
	
	
	//con.getLipinskiTable();
	//con.addLogp(value);
	//lf.calculateLogP();
	//lf.calculateHBDA();
	//lf.calculateTPSA();
	//lf.calculateROTB();
//	lf.calculateDrugLikeness();
	//lf.showMoleculeName();
	
//	lp = con.getRotb();
	
//	int j = 1;
	
//	for (int i = 0; i < 30; i++) {
//		System.out.println(j + " " + lp[i]);
//		j++;
//	}
	
	//	double baseline = (500*0.5) + (5*0.25) + (5*0.5) + (10*0) +(140*0) + (10*0.5);
	//	System.out.println(baseline);
		
	ChemGUI cg = new ChemGUI();
	//	BufferedImage im = cg.createTestImage();
	//	cg.showTable(im);
	cg.setVisible(true);
	
	//String sm = con.getSmiles("C11H9N3OS");
	//System.out.println(sm);
	//	String [][] table = con.getData();
	//	cg.makeDrugLikeSortable();
		
    //    ImageIO.write(im, "png", new File("test.png"));
		
		
		
		ArrayList arr = new ArrayList();
		
		
		Vector vec1 = new Vector();
		Vector vec2 = new Vector(10);
		Vector vec3 = new Vector(10, 5); // (Starting size, increment size)
		// Vectors can contain objects
		Vector <Integer> vec4 = new Vector<Integer>();
		vec4.add(32);
		vec4.add(5);
		
	//	con.connect();
	//	String ans = con.getSmiles("C11H9N3OS");
	//	System.out.println(ans);
		
		//vec4.remove(0);
		
	//	System.out.println("Size: " + vec4.size());
	//	System.out.println("Capacity: " + vec4.capacity());
	//	System.out.println("Value 1: " + vec4.get(1));
		

	}

}
