import java.sql.*;

import javax.swing.JOptionPane;

public class ConnectDB {
	
	// Declaring the instance variables
	Connection conn = null;	
	String username = "student";
	String password = "prince";
	String host = "jdbc:mysql://localhost/ChemDB";
	
	ResultSet resSet;
	int total_rows;
	int total_columns;
	private boolean ascending;
	private boolean descending;
	
	
	// The default class constructor
	public ConnectDB()
	{
		total_rows = 28;
		total_columns = 8;
		ascending = false;
		descending = false;
		
	}	
		
	public void connect()
	{
		try
		{
			Class.forName("org.gjt.mm.mysql.Driver");	
			conn = DriverManager.getConnection(host, username, password); 
			
			if (conn != null) {
				System.out.println("Connection Successful");
			}
			else {
				System.out.println("Connection failed");
			}
		}
		catch(ClassNotFoundException ex)
		{
			System.out.println(ex.toString());
		}
		catch(SQLException e)
		{
			System.out.println("Trying to connect to MySQL " + e);
		}		
	}
	
	
	
	
	
	
	/** This method adds the LogP values of each molecule to the database 
	 * Note: The design of this method is structurally similar to that of all other add methods for parameters**/
	public void addLogp(double x, int i) {
		
		Statement stat2 = null;
		
		// The query here is modifiable, i.e logP and the molecule index can be specified
		// The value of logP and the index of the molecule is inputed into this method
		String query = "UPDATE molecules SET LogP = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			// The query is created in the database here
			stat2 = conn.createStatement();
			
			stat2.executeUpdate(query);			// The query is executed in the database here
			
		} catch (SQLException e) {
			System.out.println("Could not execute Logp update");
			e.printStackTrace();
		}
	}
	
	
	
	/**
	 * This method adds the number of hydrogen bond acceptors for each molecule to the database 
	 * @param x
	 * @param i
	 */
	 
  public void addHBA(int x, int i) {
		
		Statement stat = null;
		String query = "UPDATE molecules SET HBA = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			stat = conn.createStatement();
			
			stat.executeUpdate(query);
			
		} catch (SQLException e) {
			System.out.println("Could not execute HBA update");
			e.printStackTrace();
		}
	}
  
  /** This method adds the number of hydrogen bond donors for each molecule to the database **/
  public void addHBD(int x, int i) {
		
		Statement stat = null;
		String query = "UPDATE molecules SET HBD = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			stat = conn.createStatement();
			
			stat.executeUpdate(query);
			
		} catch (SQLException e) {
			System.out.println("Could not execute HBD update");
			e.printStackTrace();
		}
	}
  
  
  /** This method adds the polar surface area value for each molecule to the database **/
  public void addPSA(double x, int i) {
	  
	  Statement stat = null;
		String query = "UPDATE molecules SET PSA = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			stat = conn.createStatement();
			
			stat.executeUpdate(query);
			
		} catch (SQLException e) {
			System.out.println("Could not execute PSA update");
			e.printStackTrace();
		}
  }
  
  
  
  /** This method adds the number of rotatable bonds for each molecule to the database **/
  public void addROTB(int x, int i) {
	  
	  Statement stat = null;
		String query = "UPDATE molecules SET ROTB = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			stat = conn.createStatement();
			
			stat.executeUpdate(query);
			
		} catch (SQLException e) {
			System.out.println("Could not execute ROTB update");
			e.printStackTrace();
		}
  }
  
  
 
  /** This method adds the drug-likeness score of each molecule to the database **/
  public void addScore(double x, int i) {
	  
	  Statement stat = null;
		String query = "UPDATE molecules SET score = "+x+" WHERE cd_id = "+i+"";
		
		try {
			
			stat = conn.createStatement();
			
			stat.executeUpdate(query);
			
		} catch (SQLException e) {
			System.out.println("Could not execute Score update");
			e.printStackTrace();
		}
  }
  
  
  

  
   
  /** 
   * This method retrieves LogP of every molecule stored in the database 
   * Note: The design of this method is structurally similar to that of all other get methods for parameters
   * **/
  public double[] getLogp() {
	 
	  Statement stat = null;
	  
	  //This string stores the query for the molecules table
		String query = "SELECT logp FROM molecules";
		String column = "logp";
		double [] logPvalues = new double[total_rows];		
		
		try {
			
			// The statement is created in the database here
			stat = conn.createStatement();
			
		// The query is executed in the database here	
		// This ResultSet object stores the result of the executed query	
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		// This loop parses the logP values of each molecule into an array 
		while (rs.next() != false && i < total_rows) {
			logPvalues[i] = rs.getDouble(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve LogP information");
			e.printStackTrace();
		}
		
		return logPvalues;
  }
	

  
  /** This method retrieves molecular weight for every molecule stored in the database **/
  public double[] getMolweight() {
	 
	  Statement stat = null;
		String query = "SELECT cd_molweight FROM molecules";
		String column = "cd_molweight";
		double [] molweight = new double[total_rows];
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		while (rs.next() != false && i < total_rows) {
			molweight[i] = rs.getDouble(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve molecular weight information");
			e.printStackTrace();
		}
		
		return molweight;
  }
  
  
  /** This method retrieves hydrogen bond acceptor counts for every molecule stored in the database **/
  public int[] getHBA() {
	  
	  Statement stat = null;
		String query = "SELECT hba FROM molecules";
		String column = "hba";
		int [] HBA = new int[total_rows];
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		while (rs.next() != false && i < total_rows) {
			HBA[i] = rs.getInt(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve HBA information");
			e.printStackTrace();
		}
		return HBA;
  }
  
  
  /** This method retrieves hydrogen bond donor counts for every molecule stored in the database **/
  public int[] getHBD() {
	  
	  Statement stat = null;
		String query = "SELECT hbd FROM molecules";
		String column = "hbd";
		int [] HBD = new int[total_rows];
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		while (rs.next() != false && i < total_rows) {
			HBD[i] = rs.getInt(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve HBD information");
			e.printStackTrace();
		}
		
		return HBD;
  }
  
  
  /** This method retrieves polar surface Area of every molecule stored in the database **/
  public double[] getPSA() {
	
	  Statement stat = null;
		String query = "SELECT psa FROM molecules";
		String column = "psa";
		double [] PSA = new double[total_rows];
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		while (rs.next() != false && i < total_rows) {
			PSA[i] = rs.getDouble(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve PSA information");
			e.printStackTrace();
		}
		
		return PSA;
  }
  
  
  /** This method retrieves rotatable bond counts of every molecule stored in the database **/
  public int[] getRotb() {
	  
	  Statement stat = null;
		String query = "SELECT rotb FROM molecules";
		String column = "rotb";
		int [] rotb = new int[total_rows];
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		int i = 0;
		
		
		while (rs.next() != false && i < total_rows) {
			rotb[i] = rs.getInt(column);
			
			i++;
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve ROTB information");
			e.printStackTrace();
		}
		
		return rotb;
  }
  
  
  
  /** This method retrieves SMILES of a specified molecule formula **/
 public String getSmiles(String x) {
	  
	  Statement stat = null;
		String query = "SELECT cd_smiles FROM molecules WHERE cd_formula = \""+x+"\"";
		String formula = " ";
		
		try {
			
			stat = conn.createStatement();
			
			
		ResultSet rs = stat.executeQuery(query);
		while (rs.next() != false) {
		formula = rs.getString("cd_smiles");
			
		}
			
		} catch (SQLException e) {
			System.out.println("Could not retrieve smiles information");
			e.printStackTrace();
		}
		
		return formula;
  }
  
  
 
 /** This method returns the relevant data of the molecules in the database as a table **/
 
  public String [][] getData(){
		connect();
	  String [][] moleculeDetails = new String [total_rows][total_columns];
	  String x = "";
	  
	  
	  if (ascending == true) {
		  x = "ORDER BY score";
	  }
	  
	  if (descending == true) {
		  x = "ORDER BY score DESC";
	  }
		
	  Statement stat = null;
	  String query = "SELECT DISTINCT cd_formula, cd_molweight, logp, hba, hbd, psa, rotb, score FROM molecules "+x+";";
		
		 try {
			 stat = conn.createStatement();
				
				
				ResultSet rs = stat.executeQuery(query);
				int i = 0;
				int k = 1;
		 
		
	// This loop parses every column of data in each row into a 2 dimensional array
		while (rs.next() != false && i < total_rows) {
			 k = 1;
			for (int j = 0; j < 8; j++) {
			moleculeDetails[i][j] = rs.getString(k); 
		
			k++;
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return moleculeDetails;
		 
	}
  
  
  
 /** This method returns a table with contents having parameters that obey Lipinski's rule of 5 **/
  public String [][] getLipinskiTable(){
	  
	  String [][] lipinskiTable = new String [total_rows][total_columns];
	  String x = "";
	  
	  
	  if (ascending == true) {
		  x = "ORDER BY score";
	  }
	  
	  if (descending == true) {
		  x = "ORDER BY score DESC";
	  }
		
		
	  Statement stat = null;
	  String query = "SELECT DISTINCT cd_formula, cd_molweight, logp, hba, hbd, psa, rotb, score FROM molecules WHERE cd_molweight <= 500 AND logp <= 5 AND hba <= 10 AND hbd <= 5 "+x+";";
		
		 try {
			 stat = conn.createStatement();
				
				
				ResultSet rs = stat.executeQuery(query);
				int i = 0;
				int k = 1;
		
	// This loop parses every column of data in each row into a 2 dimensional array
		while (rs.next() != false && i < total_rows) {
			 k = 1;
			for (int j = 0; j < 8; j++) {
				lipinskiTable[i][j] = rs.getString(k); 
		
			k++;
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return lipinskiTable;
  }
  
  
  
  /**
   * This method returns a table with contents having parameters that are situated leadLikeness
   * @return
   */
  public String[][] getLeadLikeness(){
	  
	  String [][] leadLike = new String [total_rows][total_columns];
	  String x = "";
	  
	  
	  if (ascending == true) {
		  x = "ORDER BY score";
	  }
	  
	  if (descending == true) {
		  x = "ORDER BY score DESC";
	  }
		
		
	  Statement stat = null;
	  String query = "SELECT DISTINCT cd_formula, cd_molweight, logp, hba, hbd, psa, rotb, score FROM molecules WHERE cd_molweight <= 300 AND logp <= 3 AND hba <= 3 AND hbd <= 3 "+x+";";
		
		 try {
			 stat = conn.createStatement();
				
				
				ResultSet rs = stat.executeQuery(query);
				int i = 0;
				int k = 1;
				
				
		
	// This loop parses every column of data in each row into a 2 dimensional array
		while (rs.next() != false && i < total_rows) {
			 k = 1;
			for (int j = 0; j < 8; j++) {
				leadLike[i][j] = rs.getString(k); 
		
			k++;
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return leadLike;
  
  }
  
  
  /** This method returns a table of specified contents **/
  
  public String [][] getSpecificTable(double x, double y, double x1, double y1, double x2, double y2, double x3, double y3, double x4, double y4, double x5, double y5){
	  String [][] specificTable = new String [total_rows][total_columns];
	  String p = "";
	  
	  
	  if (ascending == true) {
		  p = "ORDER BY score";
	  }
	  
	  if (descending == true) {
		  p = "ORDER BY score DESC";
	  }
		
		
	  Statement stat = null;
	  String query = "SELECT DISTINCT cd_formula, cd_molweight, logp, hba, hbd, psa, rotb, score FROM molecules WHERE cd_molweight BETWEEN "+x+" AND "+y+" AND logp BETWEEN "+x1+" AND "+y1+" AND hba BETWEEN "+x2+" AND "+y2+" AND hbd BETWEEN "+x3+" AND "+y3+" AND psa BETWEEN "+x4+" AND "+y4+" AND rotb BETWEEN "+x5+" AND "+y5+" "+p+";";
		
		 try {
			 stat = conn.createStatement();
				
				
				ResultSet rs = stat.executeQuery(query);
				int i = 0;
				int k = 1;
		
	// This loop parses every column of data in each row into a 2 dimensional array
		while (rs.next() != false && i < total_rows) {
			 k = 1;
			for (int j = 0; j < 8; j++) {
				specificTable[i][j] = rs.getString(k); 
		
			k++;
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return specificTable;
  }
  
  
  public String [][] getQueriedTable(String p) {
	  String [][] qTable = new String [total_rows][total_columns];
	  String x = "";
	  
	  
	  if (ascending == true) {
		  x = "ORDER BY score";
	  }
	  
	  if (descending == true) {
		  x = "ORDER BY score DESC";
	  }
		
		
	  Statement stat = null;
	  String query = "SELECT DISTINCT cd_formula, cd_molweight, logp, hba, hbd, psa, rotb, score FROM molecules WHERE cd_formula = \""+p+"\";";  
		
		 try {
			 stat = conn.createStatement();
				
				
				ResultSet rs = stat.executeQuery(query);
				int i = 0;
				int k = 1;
				
				
		
	// This loop parses every column of data in each row into a 2 dimensional array
		while (rs.next() != false && i < total_rows) {
			 k = 1;
			for (int j = 0; j < 8; j++) {
				qTable[i][j] = rs.getString(k); 
		
			k++;
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return qTable;
  
  }
  
  
  public void isAscendingOrder(boolean x) {
	  
	  if (x == true) {
		  ascending = true;
		  
	  }
	  else if (x == false) {
		  ascending = false;
	  }
	  
  }
  
  public void isDescendingOrder(boolean x) {
	  
	  if (x == true) {
		  descending = true;
		  
	  }
	  else if (x == false) {
		  descending = false;
	  }
  }
  
  
  
  
  
  
  
	
	


}
