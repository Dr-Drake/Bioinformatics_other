import java.sql.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class GymGUI extends JFrame implements ActionListener   {
	
	// Declaring the instance variables
	private GymConnect gym;
	
	private JLabel courseLabel, memlabel, instruction;
	private JPanel topPanel, midPanel, bottomPanel;
	private JButton viewCourse, book, viewBookings;
	private JTable table;
	private JTextField memId, box;
	private String cName;
	private Connection connection = null;
	
	// Constructor
	public GymGUI(GymConnect G) {
		gym = G;
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(850,450);
		this.layoutComponents();
		
		
	}
	
	// Methods for laying out components
	private void layoutComponents() {
		topPanel = new JPanel();
		bottomPanel = new JPanel();
		midPanel = new JPanel();
		
		
		//top layout of frame
		viewCourse = new JButton("View Course");
		viewCourse.addActionListener(this);
		
		viewBookings = new JButton("View Bookings");
		viewBookings.addActionListener(this);
		
		topPanel.add(viewCourse);
		topPanel.add(viewBookings);
		
	    
		
		// Middle Panel layout
		String notice1 = "To view bookings, enter a course name.                                             ";
		String notice2 = "To book members for courses, enter member Id and a course name.";
		String notice = notice1 + "\n" + notice2;
		instruction = new JLabel(notice);
		midPanel.add(instruction, BorderLayout.CENTER);
		
		
		
		
		courseLabel = new JLabel("CourseName: ");
		box = new JTextField(10);
		box.addActionListener(this);
		topPanel.add(courseLabel);
		topPanel.add(box);
		
		
		
		
		
		
		 
		// Bottom Layout Frame
		book = new JButton("Book");
		book.addActionListener(this);
		
		memlabel = new JLabel("Enter Membership ID: ");
		
		memId = new JTextField(4);
		memId.addActionListener(this);
		
		bottomPanel.add(memlabel);
		bottomPanel.add(memId);
		bottomPanel.add(book);
		
		this.add(topPanel, BorderLayout.NORTH);
		this.add(bottomPanel, BorderLayout.SOUTH);
		this.add(midPanel);
	}  
	
	
		
	public void actionPerformed(ActionEvent e) {	
		int count = 1;
		 
		
		if (e.getSource() == viewCourse) {
			gym.connectDatabase();
			
			String [] coursecol = {"Blank", "Course ID", "Course Name", "Cost (�)", "MaxPlaces", "Time", "Instructor ID", "Week Day"};
			
			String [] [] course = gym.getCourseDetails();
			table = new JTable(course, coursecol);
			JScrollPane scroll = new JScrollPane(table);
			scroll.setPreferredSize(new Dimension(800, 400));
			JOptionPane.showMessageDialog (null, scroll);
			
			gym.closeConnection();
			
		}
		else if (e.getSource() == book) {
			
			boolean Empty = box.getText().isEmpty();
  			boolean Empty2 = memId.getText().isEmpty();
			
  			if (Empty == true || Empty2 == true) {
  				JOptionPane.showMessageDialog(null, "Enter a value", "Error", JOptionPane.ERROR_MESSAGE);
  				return;
  			}
			
			gym.connectDatabase();
			
			String courseN = box.getText();
			
			
			String premem = memId.getText();
			
			gym.addOtherMemcourse(count, premem, courseN);
			
			
			gym.closeConnection();
			
		
				}
		else if (e.getSource() == viewBookings) {
              System.out.println("View Booking works");
              boolean Empty = box.getText().isEmpty();
  			
				
  			if (Empty == true) {
  				JOptionPane.showMessageDialog(null, "Enter a value", "Error", JOptionPane.ERROR_MESSAGE);
  				return;
  			}
			gym.connectDatabase();
			
			String [] courseHeader = {"Blank", "First Name", "Last Name", "Membership ID", "Course Name"};
			
			String [] [] coursebook = gym.getCourseBooking(box.getText());
			
			table = new JTable(coursebook, courseHeader);
			JScrollPane scroll = new JScrollPane(table);
			scroll.setPreferredSize(new Dimension(800, 400));
			JOptionPane.showMessageDialog (null, scroll);
			
			
			
		}
			
		
	}
	
	
	
	
}
