import javax.swing.*;
import java.awt.event.*;
public class MainConnect {

	public static void main(String[] args) {
		
		GymConnect gc = new GymConnect();
		GymGUI gym = new GymGUI(gc);
		
		gym.setVisible(true);
		gym.setTitle("Gym Boss");
		
		
		
		
	}

}
