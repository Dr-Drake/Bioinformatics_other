import java.awt.event.ActionEvent;
import java.sql.*;

import javax.swing.JComboBox;
import javax.swing.JOptionPane;
public class GymConnect  {
	
	// Declaring the instance variables
	private GymGUI gymG;
	private String database;
	private String username;
	private String password;
	private Connection connection;
	
	
	// Constructor
	public GymConnect() {
		database = "m_17_2060576e";
		username = "m_17_2060576e";
		password = "2060576e";
		connection = null;

}
	// Method for connecting to database
	public void connectDatabase() {
		try {
			connection =
			DriverManager.getConnection("jdbc:postgresql://yacata.dcs.gla.ac.uk:5432/" +
			database,username, password);
			}
			catch (SQLException e) {
			System.err.println("Connection Failed!");
			e.printStackTrace();
			return;
			}
		if (connection != null) {
		System.out.println("Connection successful" + "\n");
		}
		else {
		System.err.println("Failed to make connection!" + "\n");
		}
	}
	
	
	// Method for closing connection to database
	public void closeConnection() {
		try {
			connection.close();
			System.out.println("Connection closed");
			}
			catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Connection could not be closed � SQL exception");
			}

	}
	
	
	public String [][] getCourseDetails() {
		
		String [][] coursetable = new String [10][8];
		
		Statement stmt = null;
		 String query = " SELECT * FROM gym.course ORDER BY courseid";
		try {
		 stmt = connection.createStatement();
		 ResultSet rs = stmt.executeQuery(query);
		 
		
		int i = 0;
		 while (rs.next()) {
			 for (int j = 1; j < 8; j++) {
			coursetable[i][j] = rs.getString(j); 
		
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
	
	return coursetable;
}
	
	
	
	public void addOtherMemcourse (int count, String mem, String book) {
		Statement stmt = null;
		 String query = "INSERT INTO gym.membercourse(bookingnumber, membershipid, course) VALUES ('"+count+"', '"+mem+"','"+book+"');";
		
		 try {
		 stmt = connection.createStatement();
		
		 int rowsaffect =  stmt.executeUpdate(query);
		
		 
		 
		
		 
		}
		catch (Exception e ) {
			e.printStackTrace();
			System.err.println("error executing query " + query);
			JOptionPane.showMessageDialog(null, "Either Course Name or Member ID does not exist", "Error", JOptionPane.ERROR_MESSAGE);
			return;
		}
		
	}
	
	
	public String [][] getCourseBooking(String courseName){
		String [][] coursebooking = new String [40][5];
		
		
		Statement stmt = null;
		 String query = "SELECT * FROM gym.couresbooking WHERE coursename = '"+courseName+"'";
		
		 try {
		 stmt = connection.createStatement();
		
		 ResultSet rs = stmt.executeQuery(query);
		 
		
		int i = 0;
		 while (rs.next()) {
			 for (int j = 1; j < 5; j++) {
			coursebooking[i][j] = rs.getString(j); 
		
			
			 }
			i++;
			 
		 }	 
		 
	}
		catch (SQLException e ) {
			e.printStackTrace();
			 System.err.println("error executing query " + query);
		}
		 return coursebooking;
	}
}
	
	